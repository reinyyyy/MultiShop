$('.subjectA').on('click',function(){
	alert('바보');
	/*$.post('/MultiShop/notice/noticeView.do',
			function(data){
				$('#RSAModulus').val(data.RSAModulus);
				$('#RSAExponent').val(data.RSAExponent);
				$('#login_modal').modal({backdrop: 'static', keyboard: false});
			},'json'
	);*/
});