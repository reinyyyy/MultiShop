$( document).ready(function() {
function eventPop(){  
    window.open("../main/eventPopup.html", "오픈 기념 Event!", "width=600, height=400, toolbar=no, menubar=no, scrollbars=no, resizable=no" );  
	}  
});
